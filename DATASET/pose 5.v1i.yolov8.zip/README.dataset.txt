# pose 5 > 2025-02-22 4:21pm
https://universe.roboflow.com/pilates-x2y9r/pose-5

Provided by a Roboflow user
License: CC BY 4.0

