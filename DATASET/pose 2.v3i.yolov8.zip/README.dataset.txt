# pose 2  > 2025-03-01 5:26pm
https://universe.roboflow.com/pilates-x2y9r/pose-2-yqiof

Provided by a Roboflow user
License: CC BY 4.0

