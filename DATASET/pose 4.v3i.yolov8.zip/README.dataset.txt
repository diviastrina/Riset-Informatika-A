# pose 4 > 2025-02-19 4:03pm
https://universe.roboflow.com/pilates-x2y9r/pose-4

Provided by a Roboflow user
License: CC BY 4.0

