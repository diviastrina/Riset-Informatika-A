# pose 1 > 2025-02-18 4:06pm
https://universe.roboflow.com/pilates-x2y9r/pose-1-wzyvf

Provided by a Roboflow user
License: CC BY 4.0

