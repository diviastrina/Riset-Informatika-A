# pose 3 > 2025-02-23 5:28pm
https://universe.roboflow.com/pilates-x2y9r/pose-3-kdlej

Provided by a Roboflow user
License: CC BY 4.0

